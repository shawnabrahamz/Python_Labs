def total_cost(meters,feet,inches):
  total = (meters)*((feet*0.3048)+(inches*0.0254))
  return total
