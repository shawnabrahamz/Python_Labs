def princeify(string):
    string = string.replace("for","4")
    string = string.replace("you ", "U ")
    return string
