def height(feet,inch):
  return feet*0.3048 + inch*0.0254

def weight(w):
    output=(w*0.0714286)//1
    return f"You weigh {output} stone"